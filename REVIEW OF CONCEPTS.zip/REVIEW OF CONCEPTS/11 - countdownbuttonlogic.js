// ## Instructions
// * Using either `logic.js` (easier) or `logicOption2.js` (harder), create the click down activity using a Firebase database to store the click data on the backend.
// * Your application should be able to run on multiple browser windows simultaneously and register click events on each screen correctly.

/* global firebase */

// Initialize Firebase
// Make sure that your configuration matches your firebase script version
// (Ex. 3.0 != 3.7.1)

var config = {
  apiKey: "AIzaSyBRLd3FVYKy6MhufKAIIf-c2ZECv6H7AW0",
  authDomain: "fir-ucla-bootcamp.firebaseapp.com",
  databaseURL: "https://fir-ucla-bootcamp.firebaseio.com",
  projectId: "fir-ucla-bootcamp",
  storageBucket: "fir-ucla-bootcamp.appspot.com",
  messagingSenderId: "79682732387"
};

// var config = {
//   apiKey: "AIzaSyB4Ws5gPo9gNW9x90uXnX6XZ4uqE5QjkUY",
//   authDomain: "countdownclicker.firebaseapp.com",
//   databaseURL: "https://countdownclicker.firebaseio.com",
//   storageBucket: "countdownclicker.appspot.com",
//   messagingSenderId: "435604262542"
// };

firebase.initializeApp(config);

// Create a variable to reference the database
var database = firebase.database();

// Use the below initialValue
// REVIEW OF CONCEPTS (below): var initialValue is a CONSTANT (will never change)
var initialValue = 100;

// Use the below variable clickCounter to keep track of the clicks.
// REVIEW OF CONCEPTS (below):  
var clickCounter = initialValue;

// --------------------------------------------------------------

// At the initial load and on subsequent data value changes, get a snapshot of the current data. (I.E FIREBASE HERE)
// This callback keeps the page updated when a value changes in firebase.
// REVIEW OF CONCEPTS (below)
//1. .on("value") is predefined by Firebase.
// on() method: on(eventType: EventType, callback: function)
    // Listens for data changes at a particular location.
    // This is the primary way to read data from a Database. Your callback will be triggered for the initial data and again whenever the data changes. Use off( ) to stop receiving updates. See Retrieve Data on the Web for more details.
    // value event
    // This event will trigger once with the initial data stored at this location, and then trigger again each time the data changes. The DataSnapshot passed to the callback will be for the location at which on() was called. It won't trigger until the entire contents has been synchronized. If the location has no data, it will be triggered with an empty DataSnapshot (val() will return null).

    // .on("value", function(snapshot) {}, will trigger once with the initial data stored at this location, and then trigger again each time the data changes. Reference location is the root of the FIREBASE database.

database.ref().on("value", function(snapshot) {
  // We are now inside our .on function...

  // Console.log the "snapshot" value (a point-in-time representation of the database)
  console.log(snapshot.val());
  // This "snapshot" allows the page to get the most current values in firebase.

  // Change the value of our clickCounter to match the value in the database
  // REVIEW OF CONCEPTS (below)
  // If we were to manually change the value of clickCount (key) to 2 on FIrebase Realtime database, the ClickCounter on the webpage display would also change to 2 with $("#click-value").text(clickCounter);
  clickCounter = snapshot.val().clickCount;

  // Console Log the value of the clickCounter
  console.log(clickCounter);

  // Change the HTML using jQuery to reflect the updated clickCounter value
  $("#click-value").text(clickCounter);
  // Alternate solution to the above line
  // $("#click-value").html(clickCounter);

// If any errors are experienced, log them to console.
}, function(errorObject) {
  console.log("The read failed: " + errorObject.code);
});

// --------------------------------------------------------------
// REVIEW OF CONCEPTS (below, what is happening on webpage)
// Whenever a user clicks the click button
$("#click-button").on("click", function() {

  // Reduce the clickCounter by 1
  clickCounter--;

  // Alert User and reset the counter
  if (clickCounter === 0) {
    alert("Phew! You made it! That sure was a lot of clicking.");
    clickCounter = initialValue;
  }

  // Save new value to Firebase
  // REVIEW OF CONCEPTS (below):
  // 1. in order for Firebase Realtime database (FRD) to know what's happening on the webpage, need to set the values in the root database to reflect the clickCounter.
  // 2. clickCount is a key from the root with value of clickCounter
  database.ref().set({
    clickCount: clickCounter
  });

  // Log the value of clickCounter
  console.log(clickCounter);

});

// Whenever a user clicks the restart button
// REVIEW OF CONCEPTS (below)
// 1. restart and clickCounter to zero set clickCounter to initial value. In both instances, need to set these values in FRD so the data can synchronize (value for clickCount in FRD reflects ClickCounter)
$("#restart-button").on("click", function() {

  // Set the clickCounter back to initialValue
  clickCounter = initialValue;

  // Save new value to Firebase
  database.ref().set({
    clickCount: clickCounter
  });

  // Log the value of clickCounter
  console.log(clickCounter);

  // Change the HTML Values
  $("#click-value").text(clickCounter);

});
